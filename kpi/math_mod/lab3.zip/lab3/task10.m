f = @(X) [5*X(1)*X(2) + 4* X(1) ; 7*X(1)*X(2) - 3*X(2)];
[ox,oy] = meshgrid(-1:0.1:1,-1:0.1:1);

u = zeros(size(ox));
v = zeros(size(ox));


for i = 1:numel(ox)
    Yprime = f([ox(i); oy(i)]);
    u(i) = Yprime(1);
    v(i) = Yprime(2);
    Vmod = sqrt(u(i)^2 + v(i)^2);
    u(i) = u(i)/Vmod;
    v(i) = v(i)/Vmod;
end
quiver(ox,oy,u, v)

syms x y
eqns = [5*x*y + 4*x == 0, 7*x*y - 3*y == 0];
S = solve(eqns, [x y],'ReturnConditions', true);
S.x
S.y

