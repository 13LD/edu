syms u(x,y)
syms v(x,y)

u(x,y) = 5*x - x^2 - y*x;
v(x,y) = -2*y + x*y;

dudx = diff(u,x);
dudy = diff(u,y);
dvdx = diff(v,x);
dvdy = diff(v,y);

a = dudx(5,0);
b = dudy(5,0);
c = dvdx(5,0);
d = dvdy(5,0);

[ox,oy] = meshgrid(-8:0.4:6,-6:0.4:8);

u = zeros(size(ox));
v = zeros(size(ox));
f =@myfun;

for i = 1:numel(ox)
    u(i) = myfun(a,ox(i),b,oy(i));
    v(i) = myfun(c,ox(i),d,oy(i));
    Vmod = sqrt(u(i)^2 + v(i)^2);
    u(i) = u(i)/Vmod;
    v(i) = v(i)/Vmod;
end
quiver(ox,oy,u, v)


function lin = myfun(a,U,b,V)
lin = a*U + b*V;
end
