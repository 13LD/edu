syms x y
eqns = [5*x - x^2 - y*x == 0,-2*y + x*y == 0];
S = solve(eqns, [x y]);
S.x
S.y

f = @(X) [5*X(1) - X(1)^2  - X(1)*X(2); -2*X(2) + X(1)*X(2)];
[ox,oy] = meshgrid(-8:0.4:6,-6:0.4:8);

u = zeros(size(ox));
v = zeros(size(ox));

for i = 1:numel(ox)
    Yprime = f([ox(i); oy(i)]);
    u(i) = Yprime(1);
    v(i) = Yprime(2);
    Vmod = sqrt(u(i)^2 + v(i)^2);
    u(i) = u(i)/Vmod;
    v(i) = v(i)/Vmod;
end
quiver(ox,oy,u, v)



